## A KernelSU module for SUS-FS patched kernel ##

This module is used for installing a userspace helper tool called **ksu_susfs** and **sus_su** into /data/adb/ and provides a script example to communicate with SUS-FS kernel

